<html>

<head>
    <title> Login In </title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <style type="text/css">
    .box {
        width: 600px;
        margin: 0 auto;
        margin-top: 200px;
        border: 1px solid #ccc;
    }
    </style>

</head>

<body>
    <br />
    <div class="container box">
        <h3 align="center"> Registartion in Greenhonchos</h3><br />

        <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>

        <form method="post" action="<?php echo e(route('registration')); ?>">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label>Name</label>
                <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>" required />
            </div>
            <div class="form-group">
                <label>Enter Email</label>
                <input type="email" name="email" class="form-control" value="<?php echo e(old('email')); ?>" required />
            </div>
            <div class="form-group">
                <label>Enter Password</label>
                <input type="password" name="password" class="form-control" value="<?php echo e(old('password')); ?>" required />
            </div>
            <div class="form-group">
                <input type="submit" name="login" class="btn btn-primary" value="Register" />
            </div>
        </form>

    </div>
</body>

</html><?php /**PATH /Users/instantpay/Downloads/backupfolder/Assignment_Web/Greenhonchos/resources/views/auth/registration.blade.php ENDPATH**/ ?>